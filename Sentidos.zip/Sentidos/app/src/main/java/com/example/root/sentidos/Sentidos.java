package com.example.root.sentidos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Sentidos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sentidos);
        ImageButton one = (ImageButton) findViewById(R.id.boca);
        //one.setOnClickListener(this);
        ImageView two = (ImageView) findViewById(R.id.orelha);
        //two.setOnClickListener(this);
        ImageView three = (ImageView) findViewById(R.id.olho);
        //three.setOnClickListener(this);
        ImageView four = (ImageView) findViewById(R.id.mao);
        //four.setOnClickListener(this);
        ImageView five = (ImageView) findViewById(R.id.nariz);
        //five.setOnClickListener(this);
    }

    public void bocaExibe(View view) {
        ImageView imagem = (ImageView) findViewById(R.id.bocaresposta);
        if (imagem.getVisibility() == imagem.GONE) {
            imagem.setVisibility(View.VISIBLE);
        } else
            imagem.setVisibility(imagem.GONE);

    }

    public void orelhaExibe(View view) {
        ImageView imagem = (ImageView) findViewById(R.id.orelharesposta);
        if (imagem.getVisibility() == imagem.GONE) {
            imagem.setVisibility(View.VISIBLE);
        } else
            imagem.setVisibility(imagem.GONE);

    }

    public void narizExibe(View view) {
        ImageView imagem = (ImageView) findViewById(R.id.narizresposta);
        if (imagem.getVisibility() == imagem.GONE) {
            imagem.setVisibility(View.VISIBLE);
        } else
            imagem.setVisibility(imagem.GONE);
    }

    public void olhosExibe(View view) {
        ImageView imagem = (ImageView) findViewById(R.id.olhoresposta);
        if (imagem.getVisibility() == imagem.GONE) {
            imagem.setVisibility(View.VISIBLE);
        } else
            imagem.setVisibility(imagem.GONE);

    }

    public void maoExibe(View view) {
        ImageView imagem = (ImageView) findViewById(R.id.maoresposta);
        if (imagem.getVisibility() == imagem.GONE) {
            imagem.setVisibility(View.VISIBLE);
        } else
            imagem.setVisibility(imagem.GONE);

    }

}
